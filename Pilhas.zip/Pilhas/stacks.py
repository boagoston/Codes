# Bruno Agoston - 126714

class ContiguityNode: 
    def __init__(self, datum):
        self.datum = datum # dado
        

class LinkedNode(object):
    def __init__(self, datum):
        self.datum = datum # dado
        self.next = None # próximo